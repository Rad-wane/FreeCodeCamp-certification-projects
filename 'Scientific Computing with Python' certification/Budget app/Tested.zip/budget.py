class Category:
    def __init__(self,budget_categories):
        self.budget_categories=budget_categories
        self.ledger=[]
    
    def deposit(self, amount, description=""):
        self.ledger.append({"amount": amount, "description": description})
    
    def withdraw(self,amount, description=""):
        if self.check_funds(amount)==True:
            self.ledger.append({"amount": -amount, "description": description})
            return True
        else:
            return False
    
    def get_balance(self):
        total = 0
        for item in self.ledger:
            total += item['amount']
        return total

    def transfer(self,amount, a_budg_cat):
        if self.check_funds(amount)==True:
            self.withdraw(amount, "Transfer to "+ a_budg_cat.budget_categories)
            a_budg_cat.deposit(amount,"Transfer from "+ self.budget_categories)
            return True
        else: 
            return False
    def check_funds(self,amount):
        if self.get_balance()<amount:
            return False
        else:
            return True
        
    def __str__(self):
        output = self.budget_categories.center(30,"*")+"\n"
        for item in self.ledger:
            output += f"{item['description'][:23].ljust(23)}{format(item['amount'], '.2f').rjust(7)}\n"
        output += f"Total: {format(self.get_balance(), '.2f')}"
        return output


def create_spend_chart(list_cat):
    if len(list_cat)>4: return False
    def round_down (a,b):
        return a-a%b
    
    
    
    #Calculating %
    spent=[]
    percent =[]
    for cat in list_cat:
        total=0
        for item in cat.ledger:
            if item['amount']<0:
                total+=item['amount']
        spent.append(round(total, 2))
        
    for i in spent:
        tmp = (i/sum(spent))*100
        r_tmp=round_down(tmp, 10)
        percent.append(r_tmp)
       
    ##creating the output 
        #Creating the bars
    output="Percentage spent by category\n"
    label = range(100,-1,-10)
    n=0
    for i in label:
        add = n*" o " +"\n"
        if i  in percent:
            n+=1
            add = n*" o " +"\n"
            output+= str(i).rjust(3) +"|" +add
        else:
            output+= str(i).rjust(3) +"|" +add
        
        
        #creating the line
    for i in range(len(output.split("\n"))-1):
        nb_line=len(output.split("\n")[i])
    output+=(nb_line+1)*"-"    
        #Category name 
    output+="\n     "
    cnt=0
    name=[]
    for cat in list_cat:
        name.append(cat.budget_categories)
    len_name=[]
    for i in range(len(list_cat)):
        len_name.append(len(name[i]))
    max_len=max(len_name)
    
    for i in range(max_len):
      for nm in name:
        if len(nm)>i:
          output+=nm[i]+"  "
        else:
          output+="   "
      if i<max_len-1:
        output+="\n     "
    
    
    
                      
    print(output)
    return output